"""Count lines of code in ai_staff_v4"""
import os

root = os.path.dirname(os.path.abspath(__file__))
total_lines = 0
total_files = 0
by_dir = {}

for dirpath, dirnames, filenames in os.walk(root):
    # skip cache/output/__pycache__
    dirnames[:] = [d for d in dirnames if d not in ('.cache', 'output', '__pycache__', '.git')]
    for f in filenames:
        if f.endswith('.py'):
            fp = os.path.join(dirpath, f)
            rel = os.path.relpath(fp, root)
            try:
                n = sum(1 for _ in open(fp, encoding='utf-8', errors='ignore'))
            except:
                n = 0
            total_lines += n
            total_files += 1
            d = os.path.dirname(rel) or '.'
            by_dir[d] = by_dir.get(d, 0) + n

print(f"Python files: {total_files}")
print(f"Total lines:  {total_lines}")
print()
for d in sorted(by_dir, key=by_dir.get, reverse=True):
    print(f"  {d:40s} {by_dir[d]:>6d} lines")

# Also count non-Python
other_ext = {}
for dirpath, dirnames, filenames in os.walk(root):
    dirnames[:] = [d for d in dirnames if d not in ('.cache', 'output', '__pycache__', '.git')]
    for f in filenames:
        if not f.endswith('.py'):
            ext = os.path.splitext(f)[1] or 'no_ext'
            other_ext[ext] = other_ext.get(ext, 0) + 1

print(f"\nNon-Python files: {sum(other_ext.values())}")
for ext in sorted(other_ext, key=other_ext.get, reverse=True)[:10]:
    print(f"  {ext:10s} {other_ext[ext]:>4d} files")
