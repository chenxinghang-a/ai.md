"""Count lines of code excluding comments and blank lines"""
import os, re

root = r"c:\Users\cxx\WorkBuddy\Claw\ai_staff_v4"
total_all = 0      # all lines
total_code = 0     # code lines (no comments, no blanks)
total_blank = 0    # blank lines
total_comment = 0  # pure comment lines
total_docstring = 0 # docstring lines
by_dir = {}

for dirpath, dirnames, filenames in os.walk(root):
    dirnames[:] = [d for d in dirnames if d not in ('.cache', 'output', '__pycache__', '.git', '.checkpoints')]
    for f in filenames:
        if not f.endswith('.py'):
            continue
        fp = os.path.join(dirpath, f)
        rel_dir = os.path.relpath(dirpath, root)
        if rel_dir == '.':
            rel_dir = '_root'
        
        in_docstring = False
        docstring_delim = None
        
        try:
            with open(fp, encoding='utf-8', errors='ignore') as fh:
                for line in fh:
                    total_all += 1
                    stripped = line.strip()
                    
                    # Track docstrings (triple quotes)
                    if not in_docstring:
                        if stripped.startswith('"""') or stripped.startswith("'''"):
                            delim = stripped[:3]
                            total_docstring += 1
                            # Check if closes on same line
                            if stripped.count(delim) >= 2 and len(stripped) > 3:
                                pass  # single-line docstring
                            else:
                                in_docstring = True
                                docstring_delim = delim
                            continue
                    else:
                        total_docstring += 1
                        if docstring_delim in stripped:
                            in_docstring = False
                            docstring_delim = None
                        continue
                    
                    if stripped == '':
                        total_blank += 1
                    elif stripped.startswith('#'):
                        total_comment += 1
                    else:
                        # Code line (may have inline comment)
                        total_code += 1
                        by_dir[rel_dir] = by_dir.get(rel_dir, 0) + 1
        except:
            pass

print(f"=== ai_staff_v4 Code Statistics ===")
print(f"Total lines:       {total_all:>6d}")
print(f"Code lines:        {total_code:>6d}  (excl. comments, blanks, docstrings)")
print(f"Blank lines:       {total_blank:>6d}")
print(f"Comment lines:     {total_comment:>6d}")
print(f"Docstring lines:   {total_docstring:>6d}")
print(f"Code ratio:        {total_code/total_all*100:.1f}%")
print()
print("Code lines by module:")
for d in sorted(by_dir, key=by_dir.get, reverse=True):
    print(f"  {d:40s} {by_dir[d]:>5d}")
